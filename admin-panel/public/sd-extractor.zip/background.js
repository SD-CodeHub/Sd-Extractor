// Open the extractor as its own small popup window (draggable & resizable),
// instead of a full browser tab — similar to the Google Maps popup.
chrome.action.onClicked.addListener(() => {
  chrome.windows.create({
    url: chrome.runtime.getURL("dashboard.html"),
    type: "popup",
    width: 820,
    height: 720
  });
});
