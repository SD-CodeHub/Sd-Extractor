// ====================== CONFIG ======================
// Point these at your deployed server / website in production. When you change
// API_BASE, also update host_permissions in manifest.json to match.
const CONFIG = {
  API_BASE: 'http://localhost:5000',
  WEBSITE_URL: 'http://localhost:5173/app'   // user dashboard ("My Account")
};

let allData = [];
const seen = new Set();
let licensed = false;            // gate: extraction is blocked until true

const statusEl = document.getElementById('status');
const tableBody = document.querySelector('#dataTable tbody');
const downloadBtn = document.getElementById('downloadBtn');

// Gate elements
const gateEl = document.getElementById('licenseGate');
const appEl = document.getElementById('extractorApp');
const keyInput = document.getElementById('licenseKey');
const verifyBtn = document.getElementById('verifyBtn');
const gateMsg = document.getElementById('gateMsg');
const accountBar = document.getElementById('accountBar');
const activeKeyEl = document.getElementById('activeKey');
const signOutBtn = document.getElementById('signOutBtn');

document.getElementById('startBtn').addEventListener('click', startExtraction);
downloadBtn.addEventListener('click', downloadExcel);
verifyBtn.addEventListener('click', () => verifyLicense(keyInput.value));
keyInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') verifyLicense(keyInput.value); });
signOutBtn.addEventListener('click', signOut);

// ====================== LICENSE GATE ======================

// A stable per-device fingerprint. Must NOT include anything that changes
// between reloads (e.g. timestamps) or the device binding would never match.
function buildFingerprint() {
  return {
    userAgent: navigator.userAgent,
    language: navigator.language || 'en',
    platform: navigator.platform,
    screen: `${screen.width}x${screen.height}`,
    timezone: new Date().getTimezoneOffset(),
    hardware: navigator.hardwareConcurrency || 4
  };
}

function showGateMessage(text, type) {
  gateMsg.className = `gate-msg ${type}`;
  gateMsg.innerHTML = text;
}

function unlockApp(key) {
  licensed = true;
  gateEl.style.display = 'none';
  appEl.style.display = 'block';
  accountBar.style.display = 'flex';
  activeKeyEl.textContent = key;
}

function lockApp() {
  licensed = false;
  appEl.style.display = 'none';
  accountBar.style.display = 'none';
  gateEl.style.display = 'block';
}

async function verifyLicense(rawKey, { silent = false } = {}) {
  const key = (rawKey || '').toUpperCase().trim();
  if (!key) { showGateMessage('Please enter your license key.', 'error'); return; }

  if (!silent) { verifyBtn.disabled = true; verifyBtn.textContent = 'Verifying…'; }

  try {
    const res = await fetch(`${CONFIG.API_BASE}/verify-license`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ licenseKey: key, deviceFingerprint: buildFingerprint() })
    });
    const data = await res.json();

    if (data.valid) {
      await chrome.storage.local.set({ licenseKey: key });
      gateMsg.className = 'gate-msg';   // hide
      unlockApp(key);
      return;
    }

    // Not valid — show a helpful reason + a link back to the website.
    const link = `<a href="${CONFIG.WEBSITE_URL}" target="_blank">Open My Account</a>`;
    const reasons = {
      pending: `Your license has not been verified by the admin yet. ${link}`,
      expired: `Your plan has expired. Renew from your account. ${link}`,
      blocked: `This license has been blocked. Please contact the admin. ${link}`,
      other_device: `This key is already in use on another device. Sign out there first, or contact the admin.`,
      not_found: `License key not found. Check your key in ${link}.`
    };
    showGateMessage(reasons[data.reason] || `${data.message || 'Invalid license.'} ${link}`, 'error');
    lockApp();
  } catch (err) {
    showGateMessage(
      `Could not reach the license server. Make sure you're online and try again.`,
      'error'
    );
  } finally {
    verifyBtn.disabled = false;
    verifyBtn.textContent = 'Verify & Unlock';
  }
}

async function signOut() {
  const { licenseKey } = await chrome.storage.local.get('licenseKey');
  if (licenseKey) {
    // Unbind this device server-side so the key can be used elsewhere.
    try {
      await fetch(`${CONFIG.API_BASE}/logout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ licenseKey })
      });
    } catch (_) { /* ignore network errors on sign out */ }
  }
  await chrome.storage.local.remove('licenseKey');
  keyInput.value = '';
  showGateMessage('Signed out. Enter a license key to unlock again.', 'info');
  lockApp();
}

// On open: re-verify any saved key so a blocked/expired key can't stay unlocked.
(async function initGate() {
  const { licenseKey } = await chrome.storage.local.get('licenseKey');
  if (licenseKey) {
    keyInput.value = licenseKey;
    await verifyLicense(licenseKey, { silent: true });
  }
})();

function startExtraction() {
  if (!licensed) { showGateMessage('Please verify your license first.', 'error'); return; }
  const keyword = document.getElementById('keyword').value.trim();
  const location = document.getElementById('location').value.trim();
  const limit = parseInt(document.getElementById('limit').value, 10) || 50;

  if (!keyword || !location) return alert("Please fill both fields");

  allData = [];
  seen.clear();
  tableBody.innerHTML = "";
  downloadBtn.disabled = true;

  statusEl.textContent = "Opening Google Maps in a popup window...";

  const searchUrl = `https://www.google.com/maps/search/${encodeURIComponent(keyword + " " + location)}`;

  // Open Maps in a separate popup window (not a full tab). We can't embed
  // Maps directly inside this page — Google blocks framing — so a popup
  // window is the closest thing that still lets us scrape automatically.
  chrome.windows.create(
    { url: searchUrl, type: "popup", width: 900, height: 750 },
    (win) => {
      const tabId = win.tabs[0].id;
      mapsWindowId = win.id;
      // Give Maps time to load the first batch of results, then run the
      // scroll + click-through extraction inside the popup.
      setTimeout(() => runScraper(tabId, limit), 6000);
    }
  );
}

let mapsWindowId = null;

async function runScraper(tabId, limit) {
  statusEl.textContent = "Extracting... (this opens each business to read phone & website)";

  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      function: extractAllBusinesses,
      args: [limit]
    });
  } catch (e) {
    statusEl.textContent = "Error: " + e.message;
    return;
  }

  statusEl.textContent = `✅ Done! ${allData.length} businesses extracted.`;
  downloadBtn.disabled = allData.length === 0;

  // Close the Maps popup window now that we're finished.
  if (mapsWindowId !== null) {
    chrome.windows.remove(mapsWindowId).catch(() => {});
    mapsWindowId = null;
  }
}

/*
 * This whole function runs INSIDE the Google Maps tab.
 * It walks the results feed one business at a time: open a card, read its
 * detail panel (where phone & website live), send it back immediately so the
 * table fills live, then move on — scrolling to load more only as needed.
 * Stops once `limit` businesses have been extracted (or the list ends).
 */
async function extractAllBusinesses(limit) {
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const send = (action, payload) =>
    chrome.runtime.sendMessage({ action, ...payload });

  let processed = 0;          // how many we've actually extracted
  let noProgress = 0;         // consecutive rounds that found no new card
  const done = new Set();     // unique place URLs we've already handled

  while (processed < limit) {
    const feed = document.querySelector('div[role="feed"]');

    // Find the first loaded card we haven't processed yet.
    const cards = Array.from(document.querySelectorAll('a.hfpxzc'));
    const link = cards.find(a => a.href && !done.has(a.href));

    if (!link) {
      // No fresh card visible — scroll to load more, then retry.
      const reachedEnd = feed && /You've reached the end|end of the list/i.test(feed.innerText);
      if (reachedEnd) break;
      if (feed) feed.scrollTo(0, feed.scrollHeight);
      await sleep(1800);
      if (++noProgress >= 5) break;   // nothing new after several tries -> done
      continue;
    }
    noProgress = 0;
    done.add(link.href);

    const expectedName = link.getAttribute('aria-label') || '';

    link.scrollIntoView({ block: "center" });
    await sleep(300);
    link.click();

    // Wait for the detail panel header to update to this business.
    let panelName = '';
    for (let t = 0; t < 25; t++) {
      await sleep(250);
      panelName = document.querySelector('h1.DUwDvf')?.innerText?.trim() || '';
      if (panelName && (!expectedName || panelName === expectedName)) break;
    }

    const getText = (sel) => document.querySelector(sel)?.innerText?.trim() || '';
    const getAttr = (sel, attr) => document.querySelector(sel)?.getAttribute(attr) || '';

    const name = panelName || expectedName;

    // Rating (e.g. "4.5").
    const rating = getText('div.F7nice span[aria-hidden="true"]') || 'N/A';

    // Address.
    const address =
      getText('button[data-item-id="address"]') ||
      getAttr('button[data-item-id="address"]', 'aria-label').replace(/^Address:\s*/i, '') ||
      '';

    // Phone — lives in a button whose data-item-id is "phone:tel:+91...".
    let phone = '';
    const phoneId = getAttr('button[data-item-id^="phone:tel:"]', 'data-item-id');
    if (phoneId) {
      phone = phoneId.replace('phone:tel:', '');
    } else {
      phone = getAttr('button[data-item-id^="phone:tel:"]', 'aria-label').replace(/^Phone:\s*/i, '');
    }

    // Website — the "authority" link holds the real site URL.
    const website = getAttr('a[data-item-id="authority"]', 'href') || '';

    if (name) {
      processed++;
      send("newData", {
        row: {
          business_name: name,
          address: address || 'Not found',
          phone: phone || 'Not found',
          website: website || 'Not found',
          rating: rating || 'N/A'
        }
      });
      send("status", { text: `Extracted ${processed} / ${limit}: ${name}` });
    }

    // Go back to the results list so the next card is available again.
    // (Maps replaces the list with the detail panel when a place is open.)
    if (processed < limit) {
      const backBtn = document.querySelector('button[aria-label="Back"], button[jsaction*="back"]');
      if (backBtn) backBtn.click();
      else history.back();

      // Wait for the results feed to come back before continuing.
      for (let t = 0; t < 20; t++) {
        await sleep(250);
        if (document.querySelector('a.hfpxzc')) break;
      }
    }
  }

  send("status", { text: `Finished — extracted ${processed} businesses.` });
}

// Listen for data & status coming back from the Maps tab.
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "newData") {
    const row = message.row;
    const key = (row.business_name + '|' + row.address).toLowerCase();
    if (seen.has(key)) return;          // skip duplicates
    seen.add(key);
    allData.push(row);
    appendRow(row);
  } else if (message.action === "status") {
    statusEl.textContent = message.text;
  }
});

function appendRow(row) {
  const tr = document.createElement('tr');
  const hasSite = row.website && row.website !== 'Not found';
  tr.innerHTML = `
    <td>${escapeHtml(row.business_name)}</td>
    <td>${escapeHtml(row.address)}</td>
    <td>${escapeHtml(row.phone)}</td>
    <td>${hasSite ? `<a href="${escapeHtml(row.website)}" target="_blank">${escapeHtml(row.website)}</a>` : 'Not found'}</td>
    <td>${escapeHtml(row.rating)}</td>
  `;
  tableBody.appendChild(tr);
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function downloadExcel() {
  if (allData.length === 0) return;

  const headers = ['Business Name', 'Address', 'Phone', 'Website', 'Rating'];
  const cell = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;

  const rows = allData.map(r =>
    [r.business_name, r.address, r.phone, r.website, r.rating].map(cell).join(',')
  );

  // BOM so Excel reads UTF-8 correctly (keeps +91, accents, etc.).
  const csv = '﻿' + [headers.map(cell).join(','), ...rows].join('\r\n');

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Maps_Data_${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
